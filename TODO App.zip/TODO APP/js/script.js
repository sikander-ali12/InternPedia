document.getElementById('addTaskButton').addEventListener('click', addTaskFromInput);

document.getElementById('taskInput').addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        addTaskFromInput();
    }
});

function addTaskFromInput() {
    const taskInput = document.getElementById('taskInput').value.trim();
    if (taskInput !== "") {
        addTask(taskInput);
        document.getElementById('taskInput').value = "";
    }
}

function addTask(task) {
    const taskItem = document.createElement('li');
    taskItem.className = 'list-group-item';
    taskItem.innerHTML = `
        <span>${task}</span>
        <div>
            <button class="btn btn-success btn-sm mr-2 completeTaskButton">Complete</button>
            <button class="btn btn-danger btn-sm deleteTaskButton">Delete</button>
        </div>
    `;
    document.getElementById('pendingTasksList').appendChild(taskItem);

    const completeButton = taskItem.querySelector('.completeTaskButton');
    const deleteButton = taskItem.querySelector('.deleteTaskButton');

    completeButton.addEventListener('click', function() {
        taskItem.classList.add('completed-task');
        completeButton.disabled = true;
        completeButton.textContent = 'Completed';
        document.getElementById('completedTasksList').appendChild(taskItem);
    });

    deleteButton.addEventListener('click', function() {
        taskItem.remove();
    });
}
