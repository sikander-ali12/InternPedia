const variables = {};
function appendToDisplay(value) {
    document.getElementById('display').value += value;
}
function clearDisplay() {
    document.getElementById('display').value = '';
    document.getElementById('displayResult').value = '';
}
function calculate() {
    let expression = document.getElementById('display').value;
    let displayResult = document.getElementById('displayResult');
    try {
        for (const variable in variables) {
            const regex = new RegExp(variable, 'g');
            expression = expression.replace(regex, variables[variable]);
        }
        console.log(expression);
        const result = math.evaluate(expression);
        displayResult.value = result.toFixed(4);

    } catch (error) {
        displayResult.value = 'Error';
    }
}
function calculate() {
    const expression = document.getElementById('display').value;
    const displayResult = document.getElementById('displayResult');

    try {
       let result = expression.replace(/\b[a-zA-Z_]\w*\b/g, replaceVariable);
        result = math.evaluate(result);
        displayResult.value = result.toFixed(4);
    } catch (error) {
        displayResult.value = 'Error';
    }
}

function replaceVariable(match) {
    if (variables[match] !== undefined) {
        console.log(variables);
        return variables[match];
    } else {
        return match;
    }
}

const display = document.getElementById('display');
display.addEventListener('keypress', function (event) {
    if (event.key == 'Enter') {
        calculate();
    }

});
function createVariable() {
    const varName = document.getElementById('varName').value;
    const varValue = parseFloat(document.getElementById('varValue').value);

    if (
        varName !== 'pi' &&
        varName !== 'e' &&
        varName !== 'PI' &&
        varName !== 'E' &&
        !isNaN(varValue) &&
        /^[A-Za-z]+$/.test(varName)
    ) {
        if (!(varName in variables)) {
            variables[varName] = varValue;
            document.getElementById('varName').value = '';
            document.getElementById('varValue').value = '';
        } else {
            alert('Variable with the same name already exists.');
        }
    } else {
        alert('Invalid variable name or value. Variable names cannot be "pi, e, PI, E," and value must be a number with an alphabetic name.');
    }
}
