<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "InternPedia";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_POST['email'];
$pass = $_POST['password'];

$sql = "SELECT id FROM users WHERE email='$email' AND password='$pass'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode(['success' => true, 'userId' => $row['id']]);
} else {
    echo json_encode(['success' => false, 'message' => 'Login failed. Please check your credentials.']);
}

$conn->close();
?>
