document.addEventListener("DOMContentLoaded", function() {
    const root = document.getElementById('root');

    function showLogin() {
        root.innerHTML = `
            <div class="auth-form-container">
                <h2>User Login</h2>
                <form class="login-form" id="loginForm">
                    <label for="email">Email</label>
                    <input type="email" placeholder="youremail@gmail.com" id="email" name="email" />
                    <label for="password">Password</label>
                    <input type="password" placeholder="********" id="password" name="password" />
                    <button type="submit">Log In</button>
                </form>
                <button class="link-btn" id="switchToRegister">Don't have an account? Register here.</button>
            </div>
        `;

        document.getElementById('loginForm').addEventListener('submit', handleLoginSubmit);
        document.getElementById('switchToRegister').addEventListener('click', showRegister);
    }

    function showRegister() {
        root.innerHTML = `
            <div class="auth-form-container">
                <h2>Register</h2>
                <form class="register-form" id="registerForm">
                    <label for="name">Full name</label>
                    <input type="text" id="name" name="name" placeholder="Full Name" />
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" placeholder="youremail@gmail.com" />
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" placeholder="********" />
                    <button type="submit">Register</button>
                </form>
                <button class="link-btn" id="switchToLogin">Already have an account? Login here.</button>
            </div>
        `;

        document.getElementById('registerForm').addEventListener('submit', handleRegisterSubmit);
        document.getElementById('switchToLogin').addEventListener('click', showLogin);
    }

    async function handleLoginSubmit(event) {
        event.preventDefault();
        const email = event.target.email.value;
        const password = event.target.password.value;

        const formData = new FormData();
        formData.append('email', email);
        formData.append('password', password);

        const response = await fetch('php/login.php', {
            method: 'POST',
            body: formData,
        });

        const result = await response.json();
        if (result.success) {
            alert("Login SuccessFull.")
        } else {
            alert(result.message);
        }
    }

    async function handleRegisterSubmit(event) {
        event.preventDefault();
        const name = event.target.name.value;
        const email = event.target.email.value;
        const password = event.target.password.value;

        const formData = new FormData();
        formData.append('name', name);
        formData.append('email', email);
        formData.append('password', password);

        const response = await fetch('php/register.php', {
            method: 'POST',
            body: formData,
        });

        const result = await response.json();
        if (result.success) {
            alert("Registered Successfull.")
        } else {
            alert(result.message);
        }
    }

    showLogin();
});
