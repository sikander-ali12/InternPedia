document.getElementById('convertButton').addEventListener('click', function() {
    const tempInput = document.getElementById('temperatureInput').value;
    const unit = document.querySelector('input[name="unit"]:checked').value;
    let convertedTemp;

    if (unit === 'C') {
        // Celsius to Fahrenheit
        convertedTemp = (tempInput * 9/5) + 32;
        document.getElementById('result').innerText = `${convertedTemp.toFixed(2)} °F`;
    } else {
        // Fahrenheit to Celsius
        convertedTemp = (tempInput - 32) * 5/9;
        document.getElementById('result').innerText = `${convertedTemp.toFixed(2)} °C`;
    }
});
